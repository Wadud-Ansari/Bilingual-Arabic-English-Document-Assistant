# Data

Place the source PDFs here (they are git-ignored, not redistributed):

- `amr_en.pdf` – WHO, *Global action plan on antimicrobial resistance* (English)
- `amr_ar.pdf` – same document, Arabic

Download both from the WHO IRIS record: https://iris.who.int/handle/10665/193736

Then build the index:

```bash
python -m rag.ingest data/amr_en.pdf data/amr_ar.pdf --out index
```
