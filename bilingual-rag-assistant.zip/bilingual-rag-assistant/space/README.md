---
title: Bilingual Document Assistant
emoji: 📄
colorFrom: blue
colorTo: green
sdk: gradio
app_file: app.py
pinned: false
---

Arabic/English RAG assistant over WHO documents: hybrid search, reranking and cited answers.
Non-commercial demo. Source documents: World Health Organization (see main repository for credits).
