"""Hugging Face Space entry point (ZeroGPU). Needs chunks.json and embs.npy next to it.

Self-contained on purpose: Spaces deploy a single folder. The logic mirrors the `rag/` package.
"""
import json
import re

import gradio as gr
import numpy as np
import spaces
import torch
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder, SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer

LLM_ID = "Qwen/Qwen2.5-7B-Instruct"
MIN_SCORE = 0.30
N_CANDIDATES = 30

# ---------- data ----------
chunks = json.load(open("chunks.json", encoding="utf-8"))
embs = np.load("embs.npy")

# ---------- Arabic helpers ----------
DIACRITICS = re.compile(r"[\u0617-\u061A\u064B-\u0652]")
ARABIC = re.compile(r"[\u0600-\u06FF]")
AR_PREFIXES = sorted(["وال", "بال", "كال", "فال", "لل", "ال", "و", "ب", "ك", "ل", "ف"], key=len, reverse=True)
AR_SUFFIXES = sorted(["ات", "ون", "ين", "ان", "ها", "ية", "ة", "ه"], key=len, reverse=True)


def normalize_ar(text):
    text = DIACRITICS.sub("", text)
    text = text.replace("\u0640", "")
    return re.sub("[إأآ]", "ا", text)


def light_stem(t):
    if not ARABIC.match(t):
        return t
    for p in AR_PREFIXES:
        if t.startswith(p) and len(t) - len(p) >= 3:
            t = t[len(p):]
            break
    for s in AR_SUFFIXES:
        if t.endswith(s) and len(t) - len(s) >= 3:
            t = t[: -len(s)]
            break
    return t


def tokenize(text):
    return [light_stem(t) for t in re.findall(r"\w+", normalize_ar(text).lower())]


def detect_lang(text):
    return "Arabic" if ARABIC.search(text) else "English"


# ---------- models ----------
bm25 = BM25Okapi([tokenize(c["text"]) for c in chunks])
embedder = SentenceTransformer("BAAI/bge-m3", device="cuda")
reranker = CrossEncoder("BAAI/bge-reranker-v2-m3", max_length=512, device="cuda")
tok = AutoTokenizer.from_pretrained(LLM_ID)
llm = AutoModelForCausalLM.from_pretrained(LLM_ID, torch_dtype=torch.bfloat16).to("cuda")


# ---------- retrieval ----------
def hybrid_search(query, k_each=20, rrf_k=60, w_bm25=0.5):
    q = embedder.encode([normalize_ar(query)], normalize_embeddings=True)[0]
    dense = embs @ q
    bm = bm25.get_scores(tokenize(query))
    fused = {}
    for rank, i in enumerate(np.argsort(-dense)[:k_each]):
        fused[i] = fused.get(i, 0) + 1 / (rrf_k + rank + 1)
    for rank, i in enumerate(np.argsort(-bm)[:k_each]):
        if bm[i] > 0:
            fused[i] = fused.get(i, 0) + w_bm25 / (rrf_k + rank + 1)
    return sorted(fused, key=fused.get, reverse=True)


def retrieve(query, top_n=4):
    cands = hybrid_search(query)[:N_CANDIDATES]
    scores = reranker.predict([(query, chunks[i]["text"]) for i in cands])
    order = np.argsort(-scores)[:top_n]
    return [(int(cands[j]), float(scores[j])) for j in order]


# ---------- generation ----------
REFUSAL = {
    "English": "I couldn't find an answer to this in the loaded documents.",
    "Arabic": "لم أجد إجابة عن هذا السؤال في المستندات المحمّلة.",
}

SYSTEM = """You are a bilingual (Arabic/English) assistant that answers questions about WHO documents.
Rules:
1. Answer ONLY from the numbered context passages. Do not use outside knowledge.
2. Reply in {lang}, even if the passages are in another language.
3. Put the citation number like [1] at the end of EACH sentence or list item it supports.
4. If the passages do not contain the answer, say so in one sentence and add NO citations.
Be concise."""


@spaces.GPU(duration=90)
def answer(question):
    lang = detect_lang(question)
    hits = [h for h in retrieve(question) if h[1] >= MIN_SCORE]
    if not hits:
        return REFUSAL[lang], []
    context = "\n\n".join(
        f"[{n}] ({chunks[i]['source']}, p.{chunks[i]['page']})\n{chunks[i]['text']}"
        for n, (i, _) in enumerate(hits, 1))
    msgs = [
        {"role": "system", "content": SYSTEM.format(lang=lang)},
        {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"},
    ]
    inputs = tok.apply_chat_template(msgs, add_generation_prompt=True,
                                     return_tensors="pt", return_dict=True).to("cuda")
    with torch.no_grad():
        out = llm.generate(**inputs, max_new_tokens=400, do_sample=False)
    text = tok.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    return text, hits


def chat_fn(message, history):
    try:
        text, hits = answer(message)
    except Exception as e:
        return f"Sorry, something went wrong: {e}"
    if hits:
        src = "\n".join(
            f"[{n}] {chunks[i]['source']} · p.{chunks[i]['page']} (score {s:.2f})"
            for n, (i, s) in enumerate(hits, 1))
        text += "\n\n---\n**Sources**\n\n" + src
    return text


demo = gr.ChatInterface(
    chat_fn,
    title="Bilingual (Arabic/English) Document Assistant",
    description="Ask in Arabic or English about the loaded WHO documents. Answers cite their sources.",
    examples=[
        "What are the five strategic objectives of the global action plan?",
        "ما هي الأهداف الاستراتيجية لخطة العمل العالمية؟",
        "Who won the 2022 football World Cup?",
    ],
)

if __name__ == "__main__":
    demo.launch()
